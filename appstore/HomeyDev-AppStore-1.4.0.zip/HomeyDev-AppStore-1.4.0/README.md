# Homey Dev – App Store-pakket (versie 1.4.0)

Alles om in App Store Connect te plakken en te uploaden, in het Nederlands (NL) en Engels (EN).

## Algemeen (alle talen)

| Veld | Waarde |
|---|---|
| Support-URL | https://github.com/LRvdLinden/Athom-Homey-dev-ios/issues |
| Marketing-URL | https://lrvdlinden.app |
| Privacybeleid-URL | https://github.com/LRvdLinden/Athom-Homey-dev-ios/blob/main/PRIVACY.md |
| Copyright | © 2026 PixelForges |
| Primaire categorie | Developer Tools |
| Secundaire categorie | Utilities |
| Leeftijdsclassificatie | 4+ (geen van de inhoudsvragen van toepassing) |

## Afbeeldingen per taal (NL/ en EN/)

| Map | Formaat | Aantal | Apple: min–max |
|---|---|---|---|
| iPhone-6.3in_1206x2622 | 1206 × 2622 (iPhone 6,1"/6,3") | 6 | 1–10 |
| iPad-13in_2064x2752 | 2064 × 2752 (iPad 12,9"/13") | 4 | 1–10 (verplicht, de app draait op iPad) |
| AppleWatch_422x514 | 422 × 514 | 3 | 1–10 (verplicht, de app heeft een watch-app) |
| Mac_2880x1800 | 2880 × 1800 | 3 | 1–10 (alleen nodig als je een Mac-versie aanbiedt) |
| Creative-assets | 5244 × 2950, 3840 × 1646, 3840 × 2560, 1920 × 1280 | 4 | Uitgelicht-artwork, zonder tekst |

Upload de bestanden in de volgorde van de nummers (01, 02, …). Apple schaalt de iPhone- en iPad-screenshots zelf naar de andere schermformaten.

## Te weten

- De mockups tonen voorbeeldgegevens (fictieve apps en namen), geen echte accounts.
- Homey Dev heeft geen Mac-versie meer. De Mac-afbeeldingen zijn alleen nodig als je de app op de Mac aanbiedt; voor ‘iPad-app op Mac’ vraagt Apple ze niet.
- In de beschrijving staat dat Homey een handelsmerk van Athom B.V. is. Houd rekening met de App Review-regels over handelsmerken in de naam.

## Notitie voor App Review (EN)

```
Homey Dev is a companion app for Homey app developers. Sign in with a Homey (Athom) account on Athom's own login page, or tap "Personal Access Token" and paste a token from https://tools.developer.homey.app → My Account. A demo token can be provided on request. The app only shows the developer's own apps, organizations and Homeys; no data is sent to the developer's servers.
```
