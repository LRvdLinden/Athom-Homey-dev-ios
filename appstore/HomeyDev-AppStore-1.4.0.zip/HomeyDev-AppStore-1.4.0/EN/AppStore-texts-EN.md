# Homey Dev – App Store (English (U.S. / U.K.))

## Name (27/30)

```
Homey Dev – Developer Tools
```

## Subtitle (29/30)

```
Your Homey apps, always close
```

## Promotional text (146/170)

```
Track installs, builds and reviews of your Homey apps. Get notified the moment a build goes live or is approved, and manage your Homeys on the go.
```

## Keywords (89/100)

```
homey,athom,developer,app,installs,build,certification,zigbee,zwave,smart home,widget,sdk
```

## Description (1744/4000)

```
Homey Dev brings Homey Developer Tools to your iPhone, iPad and Apple Watch. See at a glance how your Homey apps are doing, publish builds and reply to reviews, wherever you are.

HOME
• Totals across all your apps and organizations: installs, Cloud and Local, apps in review and average rating
• Installs per app and your top performers

MY APPS
• Statistics and install trend (7 days, 30 days, 90 days, 1 year or all)
• Live build with changelog and permissions, all builds, crashes with stack traces, suggestions and devices per driver
• Publish builds to Test or Live, submit for certification or retract, plus the reviewer's comments
• Reply to reviews and manage email notifications

ORGANIZATIONS
• Apps, members and totals per organization
• Invite members, change roles and remove members (owner or admin)

HOMEYS
• Control devices, run flows, restart apps and view their settings
• Logic variables, timeline and system info
• Built-in tools: System, Insights, Zigbee, Z-Wave, Bluetooth LE, RF, Infrared, Images and Videos
• Web API Playground

NOTIFICATIONS
• A notification for every status change: new build, Test, in review, approved, rejected and live
• Choose which kinds you want

WIDGETS AND APPLE WATCH
• Widgets for installs, top apps and review & crashes
• Apple Watch app with an overview, your apps, things that need attention and complications for your watch face

AND MORE
• Multiple accounts, quick switching
• Light, dark or automatic
• Dutch, English, German and French

Sign in with your own Homey account on Athom's login page, or with a Personal Access Token. Your data stays on your device: no ads, no tracking.

Homey Dev is an unofficial app by PixelForges. Homey and the Homey logo are trademarks of Athom B.V.
```

## What's New in This Version (280/4000)

```
• New: a ‘More apps from the developer’ card at the bottom of Account
• In-app and push notifications now work side by side, without duplicates
• Faster loading of apps, organizations and widgets
• Fully translated into Dutch, English, German and French, including the Apple Watch
```
