# Homey Dev – App Store (Nederlands)

## Naam (27/30)

```
Homey Dev – Developer Tools
```

## Ondertitel (29/30)

```
Je Homey-apps altijd dichtbij
```

## Promotietekst (144/170)

```
Volg installs, builds en reviews van je Homey-apps. Krijg een melding zodra een build live gaat of is goedgekeurd, en beheer je Homeys onderweg.
```

## Trefwoorden (98/100)

```
homey,athom,developer,ontwikkelaar,app,installs,build,certificering,zigbee,zwave,smart home,widget
```

## Beschrijving (1823/4000)

```
Homey Dev brengt Homey Developer Tools naar je iPhone, iPad en Apple Watch. Zie in één oogopslag hoe je Homey-apps het doen, publiceer builds en reageer op reviews, waar je ook bent.

HOME
• Totalen over al je apps en organisaties: installs, Cloud en Local, apps in review en gemiddelde rating
• Installaties per app en je best presterende apps

MY APPS
• Statistieken en installatietrend (7 dagen, 30 dagen, 90 dagen, 1 jaar of alles)
• Live-build met changelog en rechten, alle builds, crashes met stacktrace, suggesties en apparaten per driver
• Builds naar Test of Live zetten, indienen voor certificering of terugtrekken, plus de opmerkingen van de reviewer
• Reviews beantwoorden en e-mailmeldingen beheren

ORGANISATIES
• Apps, leden en totalen per organisatie
• Leden uitnodigen, rollen aanpassen en verwijderen (eigenaar of beheerder)

HOMEYS
• Apparaten bedienen, flows starten, apps herstarten en instellingen bekijken
• Logic-variabelen, tijdlijn en systeeminfo
• Ingebouwde tools: Systeem, Insights, Zigbee, Z-Wave, Bluetooth LE, RF, Infrarood, Afbeeldingen en Video's
• Web API Playground

MELDINGEN
• Een melding bij elke statuswijziging: nieuwe build, Test, in review, goedgekeurd, afgekeurd en live
• Zelf in te stellen per soort melding

WIDGETS EN APPLE WATCH
• Widgets voor installs, top-apps en review & crashes
• Apple Watch-app met overzicht, je apps, aandachtspunten en complicaties voor je wijzerplaat

EN VERDER
• Meerdere accounts, snel wisselen
• Licht, donker of automatisch
• Nederlands, Engels, Duits en Frans

Inloggen gaat met je eigen Homey-account op de inlogpagina van Athom, of met een Personal Access Token. Je gegevens blijven op je toestel: geen advertenties, geen tracking.

Homey Dev is een onofficiële app van PixelForges. Homey en het Homey-logo zijn handelsmerken van Athom B.V.
```

## Nieuw in deze versie (282/4000)

```
• Nieuw: de kaart ‘Meer apps van de ontwikkelaar’ onderaan Account
• Meldingen van de app en via push werken naast elkaar, zonder dubbele meldingen
• Sneller laden van apps, organisaties en widgets
• Volledig vertaald in het Nederlands, Engels, Duits en Frans, ook op de Apple Watch
```
